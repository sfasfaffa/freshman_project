package com.example.bigwork2_14.service;

import com.example.bigwork2_14.dao.UserDao;
import com.example.bigwork2_14.pojo.User;

public class UserServiceImpl implements UserService{

}
