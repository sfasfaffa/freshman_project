package com.example.bigwork2_14.controller;

import com.example.bigwork2_14.dao.ClazzDao;
import com.example.bigwork2_14.dao.UserDao;
import com.example.bigwork2_14.pojo.Clazz;
import com.example.bigwork2_14.pojo.User;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
@Controller
public class TeacherController {
    @Autowired
    UserDao userDao;
    @Autowired
    ClazzDao clazzDao;
    @RequestMapping("/teacher/addclazz")
    public String add(){
        return "teacher/addclazz";
    }
    @RequestMapping  (value = "/doaddclazz")
    public String girlAdd(@RequestParam("clazzname") String clazzname
    ){
        Clazz clazz = new Clazz();
        clazz.setName(clazzname);
        Subject subject = SecurityUtils.getSubject();
        User currentUser = (User)subject.getPrincipal();
        clazz.setTeacherId(currentUser.getId());
        clazz.setState(0);
        clazzDao.save(clazz);
        return "role/teacher";
    }
    @RequestMapping (value = "/teacher/myclazzes")
    public String myClazz(Model model){
        Subject subject = SecurityUtils.getSubject();
        User currentUser = (User)subject.getPrincipal();
        model.addAttribute("msg",clazzDao.findByTeacherId(currentUser.getId()));
        return "/teacher/myclazzes";
    }
}
