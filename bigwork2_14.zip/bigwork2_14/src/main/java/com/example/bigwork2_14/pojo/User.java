package com.example.bigwork2_14.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity(name = "user")

public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private int id;
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "clazzes_users",uniqueConstraints = {@UniqueConstraint(columnNames = {"c_id","u_id"})},
            joinColumns = { @JoinColumn(name="u_id",referencedColumnName = "id")},
            inverseJoinColumns = {@JoinColumn(name = "c_id",referencedColumnName = "id")})
    private List<Clazz>  clazzes= new ArrayList<>();
    @Column
    private String name;
    @Column
    private String pwd;
    @Column
    private String perms;
    @Column
    public String getPerms() {
        return perms;
    }

    public List<Clazz> getClazzes() {
        return clazzes;
    }

    public void setClazzes(List<Clazz> clazzes) {
        this.clazzes = clazzes;
    }

    public void setPerms(String perms) {
        this.perms = perms;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
