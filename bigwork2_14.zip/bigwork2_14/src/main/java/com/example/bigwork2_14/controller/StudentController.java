package com.example.bigwork2_14.controller;

import com.example.bigwork2_14.dao.ClazzDao;
import com.example.bigwork2_14.dao.UserDao;
import com.example.bigwork2_14.pojo.Clazz;
import com.example.bigwork2_14.pojo.User;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@Controller
public class StudentController {
    @Autowired
    ClazzDao clazzDao;
    @Autowired
    UserDao userDao;
    @RequestMapping("/student/chooseclazz")
    public String stuChoClaz(Model model){
        List<Clazz> clazzes= clazzDao.findByState(1);

            model.addAttribute("msg",clazzes.toString());

        return "/student/chooseclazz";
    }
    @RequestMapping("/chooseclazz")
    public String stuChoClaz(@RequestParam("id") Integer id,Model model){
        Clazz clazz = clazzDao.getById(id);
        if(clazz.getState()==0||clazz==null){
            model.addAttribute("outp","error");
            return "/student/chooseclazz";
        }else if (clazz.getState()==1) {
            Subject subject = SecurityUtils.getSubject();
            User currentUser = (User) subject.getPrincipal();
            currentUser.getClazzes().add(clazz);
            userDao.save(currentUser);
        }
        return "role/student";
    }
    @RequestMapping("/student/lookover")
    public String lookOver(Model model){
        Subject subject = SecurityUtils.getSubject();
        User currentUser = (User) subject.getPrincipal();
        List<Clazz> clazzes = currentUser.getClazzes();
        model.addAttribute("msg",clazzes.toString());
        return "/student/lookover";
    }
    @RequestMapping("/student/dropclazz")
    public String dropClazz(){
        return "/student/dropclazz";
    }
    @RequestMapping("/dodropclazz")
    @Transactional
    public String doDropClazz(@RequestParam("id")Integer id){
        Subject subject = SecurityUtils.getSubject();
        User currentUser = (User) subject.getPrincipal();
        List<Clazz> clazzes = currentUser.getClazzes();
        List<Clazz> newClazzes = new ArrayList<>();
        for (Clazz clazz : clazzes) {
            if(clazz.getId()!=id){
                newClazzes.add(clazz);
            }
        }
        currentUser.setClazzes(null);
        currentUser.setClazzes(newClazzes);
        userDao.save(currentUser);
        return "/role/student";
    }
}
/*
public void grantPrograms(Long roleId, Long[] programIds) {
    Role role = get(roleId);
    Set<Program> programs = role.getPrograms();        //第一趟遍历， 删除未被选中的节目
    for (Iterator<Program> it = programs.iterator();
         it.hasNext(); ) {
        Program program = it.next();
        if (!ArrayUtils.contains(programIds, program.getId())) {
            program.getRoles().remove(role);
            it.remove(); //开始用programs.remove(program);抛java.util.ConcurrentModificationException			}
        }        //第二趟遍历 插入新选中的节目
        for (Long selectProgramId : programIds) {
            if (isNewSelected(programs, selectProgramId)) {
                Program p = get(Program.class, selectProgramId);
                p.getRoles().add(role); //添加角色到节目的关联
                programs.add(p);
            }
        }
        save(role);
    }
    private boolean isNewSelected (Set < Program > programs, Long selecteId){
        for (Program program : programs)
            if (program.getId() == selecteId) return false;
        return true;
    }
}*/