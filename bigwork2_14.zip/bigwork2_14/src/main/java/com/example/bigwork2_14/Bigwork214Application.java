package com.example.bigwork2_14;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication

public class Bigwork214Application {

    public static void main(String[] args) {
        SpringApplication.run(Bigwork214Application.class, args);
    }

}
