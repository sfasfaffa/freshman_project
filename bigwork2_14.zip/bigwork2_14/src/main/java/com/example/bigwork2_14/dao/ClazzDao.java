package com.example.bigwork2_14.dao;

import com.example.bigwork2_14.pojo.Clazz;
import com.example.bigwork2_14.pojo.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ClazzDao extends JpaRepository<Clazz,Integer> {
    public Clazz findByName(String name);
    public List<Clazz> findByState(Integer state);
    public List<Clazz> findByTeacherId(Integer id);
}
