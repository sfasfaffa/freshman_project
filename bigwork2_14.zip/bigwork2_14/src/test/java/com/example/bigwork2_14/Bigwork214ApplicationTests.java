package com.example.bigwork2_14;

import com.example.bigwork2_14.dao.ClazzDao;
import com.example.bigwork2_14.dao.UserDao;
import com.example.bigwork2_14.service.UserServiceImpl;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bigwork214ApplicationTests {

    @Autowired
    UserDao userDao;
    @Autowired
    ClazzDao clazzDao;
    @Test
    public void test(){
        System.out.println("初始化了吗？");
    }

}
